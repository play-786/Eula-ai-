import React, { useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { motion } from "framer-motion";
import { Upload, Image as ImageIcon, FileImage, FileScan, FilePlus2, Download, LogIn, LogOut, UserPlus, Sparkles, Layers, Scissors, Clock, Play, Loader2, ShieldCheck, Crown, Settings } from "lucide-react";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

// ---------- CONFIG: CHANGE THESE ----------
const SUPABASE_URL = "https://lhrhdzhkevipfmniqhxs.supabase.co"; // derived from your key's `ref`
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxocmhkemhrZXZpcGZtbmlxaHhzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY5ODY0NTAsImV4cCI6MjA3MjU2MjQ1MH0.YPRW59ha5zWy73XfoPMoSxj0byPkdHfPV-Z1MeTsOLQ";
// -----------------------------------------

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Simple shadcn-like button
const Button = ({ className = "", disabled, children, ...props }) => (
  <button
    className={`px-4 py-2 rounded-2xl shadow-sm border hover:shadow transition disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    disabled={disabled}
    {...props}
  >
    {children}
  </button>
);

const Card = ({ className = "", children }) => (
  <div className={`rounded-2xl border shadow-sm p-4 bg-white ${className}`}>{children}</div>
);

function useAuth() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let ignore = false;
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!ignore) setUser(data.session?.user ?? null);
      setLoading(false);
    })();
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => {
      sub.subscription?.unsubscribe?.();
      ignore = true;
    };
  }, []);
  return { user, loading };
}

// ---------- Utilities ----------
async function fileToImageBitmap(file) {
  const blobURL = URL.createObjectURL(file);
  const img = await createImageBitmap(await fetch(blobURL).then(r => r.blob()));
  URL.revokeObjectURL(blobURL);
  return img;
}

function canvasToBlob(canvas, type = "image/jpeg", quality = 0.8) {
  return new Promise((resolve) => canvas.toBlob(resolve, type, quality));
}

async function compressImage(file, quality = 0.7, maxW = 1920, maxH = 1920) {
  const img = await fileToImageBitmap(file);
  const ratio = Math.min(maxW / img.width, maxH / img.height, 1);
  const w = Math.round(img.width * ratio);
  const h = Math.round(img.height * ratio);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0, w, h);
  const blob = await canvasToBlob(canvas, "image/jpeg", quality);
  return new File([blob], `${file.name.replace(/\.[^.]+$/, "")}-compressed.jpg`, { type: "image/jpeg" });
}

async function enhanceImage(file, { sharpen = true, contrast = 1.1, brightness = 1.05 } = {}) {
  const img = await fileToImageBitmap(file);
  const canvas = document.createElement("canvas");
  canvas.width = img.width;
  canvas.height = img.height;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0);

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const d = imageData.data;

  const c = contrast;
  const b = (brightness - 1) * 255;
  for (let i = 0; i < d.length; i += 4) {
    d[i] = Math.min(255, Math.max(0, c * d[i] + b));
    d[i+1] = Math.min(255, Math.max(0, c * d[i+1] + b));
    d[i+2] = Math.min(255, Math.max(0, c * d[i+2] + b));
  }

  if (sharpen) {
    const w = canvas.width, h = canvas.height;
    const src = new Uint8ClampedArray(d);
    const k = [0, -1, 0, -1, 5, -1, 0, -1, 0];
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        for (let ch = 0; ch < 3; ch++) {
          const idx = (y * w + x) * 4 + ch;
          const v =
            src[idx - 4 - w * 4] * k[0] +
            src[idx - w * 4] * k[1] +
            src[idx + 4 - w * 4] * k[2] +
            src[idx - 4] * k[3] +
            src[idx] * k[4] +
            src[idx + 4] * k[5] +
            src[idx - 4 + w * 4] * k[6] +
            src[idx + w * 4] * k[7] +
            src[idx + 4 + w * 4] * k[8];
          d[idx] = Math.max(0, Math.min(255, v));
        }
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
  const blob = await canvasToBlob(canvas, "image/jpeg", 0.9);
  return new File([blob], `${file.name.replace(/\.[^.]+$/, "")}-enhanced.jpg`, { type: "image/jpeg" });
}

async function imagesToPdf(files) {
  const pdfDoc = await PDFDocument.create();
  for (const file of files) {
    const bytes = await file.arrayBuffer();
    const img = await createImageBitmap(new Blob([bytes]));
    const page = pdfDoc.addPage([img.width, img.height]);
    const imgBytes = new Uint8Array(await new Response(new Blob([bytes])).arrayBuffer());
    let embed;
    if (file.type === "image/png") {
      embed = await pdfDoc.embedPng(imgBytes);
    } else {
      embed = await pdfDoc.embedJpg(imgBytes);
    }
    page.drawImage(embed, { x: 0, y: 0, width: img.width, height: img.height });
  }
  const pdfBytes = await pdfDoc.save();
  return new File([pdfBytes], `images-${Date.now()}.pdf`, { type: "application/pdf" });
}

async function mergePdfs(files) {
  const out = await PDFDocument.create();
  for (const f of files) {
    const src = await PDFDocument.load(await f.arrayBuffer());
    const pages = await out.copyPages(src, src.getPageIndices());
    for (const p of pages) out.addPage(p);
  }
  const bytes = await out.save();
  return new File([bytes], `merged-${Date.now()}.pdf`, { type: "application/pdf" });
}

function ToolCard({ title, icon: Icon, children, description }) {
  return (
    <Card className="space-y-3">
      <div className="flex items-center gap-2">
        <Icon className="w-5 h-5" />
        <h3 className="text-lg font-semibold">{title}</h3>
      </div>
      {description && <p className="text-sm text-gray-600">{description}</p>}
      {children}
    </Card>
  );
}

function DownloadItem({ file }) {
  const url = useMemo(() => URL.createObjectURL(file), [file]);
  useEffect(() => () => URL.revokeObjectURL(url), [url]);
  return (
    <a href={url} download={file.name} className="text-sm underline flex items-center gap-2">
      Download {file.name}
    </a>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white text-gray-900">
      <h1 className="text-2xl font-bold text-center py-4">Eula AI – Image & PDF Toolkit</h1>
      <p className="text-center text-gray-500 mb-6">Upload files and tools will auto-run.</p>
      {/* Tools would be added here in full version */}
    </div>
  );
}
